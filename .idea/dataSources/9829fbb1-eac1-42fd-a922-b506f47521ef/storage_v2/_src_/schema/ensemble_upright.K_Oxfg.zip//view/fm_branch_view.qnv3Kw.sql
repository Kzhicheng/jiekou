create definer = bke_dev@`%` view fm_branch_view as
select `ensemble_upright`.`fm_branch`.`BRANCH` AS `branch`, `ensemble_upright`.`fm_branch`.`BRANCH` AS `sub_branch`
from `ensemble_upright`.`fm_branch`
union
select `ensemble_upright`.`fm_branch`.`ATTACHED_TO` AS `branch`,
       `ensemble_upright`.`fm_branch`.`BRANCH`      AS `sub_branch`
from `ensemble_upright`.`fm_branch`
union
select NULL AS `branch`, `ensemble_upright`.`fm_branch`.`BRANCH` AS `sub_branch`
from `ensemble_upright`.`fm_branch`
union
select distinct `a`.`BRANCH` AS `branch`, `c`.`BRANCH` AS `branch`
from `ensemble_upright`.`fm_branch` `a`
         join `ensemble_upright`.`fm_branch` `b`
         join `ensemble_upright`.`fm_branch` `c`
where ((`b`.`ATTACHED_TO` = `a`.`BRANCH`) and (`c`.`ATTACHED_TO` = `b`.`BRANCH`));

